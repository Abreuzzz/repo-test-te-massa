
import respx
import httpx
from massas.app.container import build_workflow

@respx.mock
def test_workflow_abertura_conta_filhos():
    # Mock 4Devs
    respx.post("https://www.4devs.com.br/ferramentas_online.php").mock(
        return_value=httpx.Response(200, json={"cpf":"12345678901"})
    )
    # Mock consulta CPF: 404 (não encontrado) -> nosso gateway retorna None
    respx.get("https://hom-h1-api-gateway/v1/pessoas_fisicas/12345678901").mock(
        return_value=httpx.Response(404, json={})
    )
    # Mock HW
    respx.post("https://api-hw-hom/v1/dados_pessoais_fiscais/dados_especificos").mock(
        return_value=httpx.Response(200, json={"id_cliente": "cli_abc"})
    )
    respx.post("https://api-hw-hom/v1/consentimentos/oferta").mock(
        return_value=httpx.Response(200, json={"id_jornada": "jour_123"})
    )
    respx.post("https://api-hw-hom/v1/consentimentos/validar").mock(
        return_value=httpx.Response(200, json={"ok": True})
    )
    respx.post("https://api-hw-hom/v1/consentimentos/salvar").mock(
        return_value=httpx.Response(200, json={"ok": True})
    )

    wf = build_workflow("abertura_conta_filhos")
    out = wf.run()
    assert out["cpf"] == "12345678901"
    assert out["id_cliente"] == "cli_abc"
    assert out["id_jornada"] == "jour_123"
