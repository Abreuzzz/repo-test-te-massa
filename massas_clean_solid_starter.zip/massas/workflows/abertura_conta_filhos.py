
from .base import Workflow
from massas.usecases.generate_cpf import GenerateCpf
from massas.usecases.consult_cpf import ConsultCpf
from massas.usecases.register_cpf import RegisterCpf
from massas.usecases.offer_consent import OfferConsent
from massas.usecases.validate_requirements import ValidateRequirements
from massas.usecases.save_consent import SaveConsent
from massas.domain.entities import Cliente
from massas.domain.value_objects import CPF

class AberturaContaFilhos(Workflow):
    def __init__(self, gen: GenerateCpf, consult: ConsultCpf, reg: RegisterCpf,
                 offer: OfferConsent, validate: ValidateRequirements, save: SaveConsent,
                 menor_de_idade: bool = True):
        self.gen, self.consult, self.reg = gen, consult, reg
        self.offer, self.validate, self.save = offer, validate, save
        self.menor_de_idade = menor_de_idade

    def run(self) -> dict:
        cpf = self.gen.execute()
        data = self.consult.execute(cpf)

        if data is None:
            id_cliente = self.reg.execute(cpf)
        else:
            id_cliente = data.get("id_cliente")

        cliente = Cliente(id_cliente=id_cliente, cpf=cpf)

        id_jornada = self.offer.execute(cpf)
        self.validate.execute(id_jornada, cpf)
        self.save.execute(id_jornada, aceito=True, cpf=cpf)

        return {
            "cpf": cpf.numero,
            "id_cliente": id_cliente,
            "id_jornada": id_jornada
        }
