
from massas.domain.value_objects import CPF
from massas.infra.hw_api import HwApi

class SaveConsent:
    def __init__(self, hw: HwApi):
        self.hw = hw

    def execute(self, id_jornada: str, aceito: bool, cpf: CPF) -> None:
        self.hw.salvar_consentimento(id_jornada, aceito, cpf)
