
from massas.domain.value_objects import CPF
from massas.infra.cpf_provider import CpfProvider

class GenerateCpf:
    def __init__(self, cpf_provider: CpfProvider):
        self.cpf_provider = cpf_provider

    def execute(self) -> CPF:
        return self.cpf_provider.gerar_cpf()
