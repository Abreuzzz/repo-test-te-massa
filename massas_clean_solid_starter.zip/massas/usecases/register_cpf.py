
from massas.domain.value_objects import CPF
from massas.infra.hw_api import HwApi

class RegisterCpf:
    def __init__(self, hw: HwApi):
        self.hw = hw

    def execute(self, cpf: CPF) -> str:
        return self.hw.cadastrar_cpf(cpf)
