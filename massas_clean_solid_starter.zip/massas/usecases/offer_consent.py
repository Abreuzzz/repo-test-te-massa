
from massas.domain.value_objects import CPF
from massas.infra.hw_api import HwApi

class OfferConsent:
    def __init__(self, hw: HwApi):
        self.hw = hw

    def execute(self, cpf: CPF) -> str:
        return self.hw.ofertar_consentimento(cpf)
