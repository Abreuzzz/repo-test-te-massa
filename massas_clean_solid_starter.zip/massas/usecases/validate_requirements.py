
from massas.domain.value_objects import CPF
from massas.infra.hw_api import HwApi

class ValidateRequirements:
    def __init__(self, hw: HwApi):
        self.hw = hw

    def execute(self, id_jornada: str, cpf: CPF) -> None:
        self.hw.validar_requisitos(id_jornada, cpf)
