
from pydantic import BaseModel
from .value_objects import CPF

class Cliente(BaseModel):
    id_cliente: str | None = None
    cpf: CPF
    data_nascimento: str | None = None  # ISO yyyy-mm-dd

class Consentimento(BaseModel):
    id_jornada: str
    cpf: CPF
    aceito: bool
