
from pydantic import BaseModel, Field, field_validator

class CPF(BaseModel):
    numero: str = Field(..., min_length=11, max_length=11)

    @field_validator("numero")
    @classmethod
    def only_digits(cls, v: str):
        if not v.isdigit():
            raise ValueError("CPF deve conter apenas dígitos")
        return v
