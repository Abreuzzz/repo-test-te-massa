
from massas.infra.settings import Settings
from massas.infra.http_gateway import HttpGateway
from massas.infra.cpf_provider import CpfProvider
from massas.infra.hw_api import HwApi

from massas.usecases.generate_cpf import GenerateCpf
from massas.usecases.consult_cpf import ConsultCpf
from massas.usecases.register_cpf import RegisterCpf
from massas.usecases.offer_consent import OfferConsent
from massas.usecases.validate_requirements import ValidateRequirements
from massas.usecases.save_consent import SaveConsent

from massas.workflows.abertura_conta_filhos import AberturaContaFilhos

def build_workflow(scenario: str):
    s = Settings()

    gw_4devs = HttpGateway(s.FOUR_DEVS_BASE)
    gw_consulta = HttpGateway(s.CONSULTA_BASE)
    gw_hw = HttpGateway(s.HW_BASE)

    cpf_provider = CpfProvider(gw_4devs, gw_consulta)
    hw = HwApi(gw_hw)

    gen = GenerateCpf(cpf_provider)
    consult = ConsultCpf(cpf_provider)
    register = RegisterCpf(hw)
    offer = OfferConsent(hw)
    validate = ValidateRequirements(hw)
    save = SaveConsent(hw)

    if scenario == "abertura_conta_filhos":
        return AberturaContaFilhos(gen, consult, register, offer, validate, save)
    raise ValueError(f"Cenário não suportado: {scenario}")
