
import argparse, json
from .container import build_workflow

def main():
    parser = argparse.ArgumentParser(description="Gerador de massas")
    parser.add_argument("--cenario", required=True, help="ex: abertura_conta_filhos")
    args = parser.parse_args()

    wf = build_workflow(args.cenario)
    resultado = wf.run()
    print(json.dumps(resultado, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
