
from .http_gateway import HttpGateway
from massas.domain.value_objects import CPF

class HwApi:
    def __init__(self, gw: HttpGateway):
        self._gw = gw

    def cadastrar_cpf(self, cpf: CPF) -> str:
        data = self._gw.post("/v1/dados_pessoais_fiscais/dados_especificos", json={"cpf": cpf.numero})
        return data["id_cliente"]

    def ofertar_consentimento(self, cpf: CPF) -> str:
        data = self._gw.post("/v1/consentimentos/oferta", json={"cpf": cpf.numero})
        return data["id_jornada"]

    def validar_requisitos(self, id_jornada: str, cpf: CPF) -> None:
        self._gw.post("/v1/consentimentos/validar", json={"id_jornada": id_jornada, "cpf": cpf.numero})

    def salvar_consentimento(self, id_jornada: str, aceito: bool, cpf: CPF) -> None:
        self._gw.post("/v1/consentimentos/salvar", json={"id_jornada": id_jornada, "aceito": aceito, "cpf": cpf.numero})
