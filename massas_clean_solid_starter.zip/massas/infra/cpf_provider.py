
from .http_gateway import HttpGateway
from massas.domain.value_objects import CPF
from massas.domain.errors import ExternalServiceError

class CpfProvider:
    def __init__(self, four_devs: HttpGateway, consulta_api: HttpGateway):
        self._four_devs = four_devs
        self._consulta = consulta_api

    def gerar_cpf(self) -> CPF:
        try:
            data = self._four_devs.post("/ferramentas_online.php", json={"acao": "gerar_cpf"})
            # Assume retorno {'cpf': '12345678901'}
            return CPF(numero=str(data.get("cpf")))
        except Exception as e:
            raise ExternalServiceError(f"Falha ao gerar CPF: {e}") from e

    def consultar(self, cpf: CPF) -> dict | None:
        return self._consulta.get(f"/v1/pessoas_fisicas/{cpf.numero}")
