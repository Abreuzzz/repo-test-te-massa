
from pydantic import BaseSettings

class Settings(BaseSettings):
    FOUR_DEVS_BASE: str = "https://www.4devs.com.br"
    CONSULTA_BASE: str = "https://hom-h1-api-gateway"
    HW_BASE: str = "https://api-hw-hom"

    class Config:
        env_file = ".env"
