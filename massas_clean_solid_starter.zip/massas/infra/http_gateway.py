
import httpx
from tenacity import retry, stop_after_attempt, wait_fixed

class HttpGateway:
    def __init__(self, base_url: str, timeout: int = 10, headers: dict | None = None):
        self.client = httpx.Client(base_url=base_url, timeout=timeout, headers=headers or {})

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(1))
    def post(self, path: str, json: dict):
        r = self.client.post(path, json=json)
        r.raise_for_status()
        return r.json()

    @retry(stop=stop_after_attempt(3), wait=wait_fixed(1))
    def get(self, path: str):
        r = self.client.get(path)
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r.json()
