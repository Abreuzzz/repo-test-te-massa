
# Gerador de Massas (Clean/SOLID)

## Rodando
```bash
python -m massas.app.cli --cenario abertura_conta_filhos
```

Configure variáveis em `.env` (ver `.env.example`).

## Estrutura
- `domain/` tipos e erros
- `infra/` gateways HTTP e adapters
- `usecases/` um por etapa
- `workflows/` orquestração por cenário
- `app/` CLI e container de injeção
- `tests/` testes com `respx` (mocks HTTP)
